
var characterX = 80;
var characterY = 80;

var UP_ARROW = 80; 
var DOWN_ARROW = 80;
var LEFT_ARROW = 80;
var RIGHT_ARROW = 80;

var shapeX = 50;
var shapeY = 50;
var shapeXSpeed = 80;
var shapeYSpeed = 80;

var mouseShapeX;
var mouseShapeY;
function setup()
{
    createCanvas(800, 400);
    shapeXSpeed = Math.floor(Math.random() * (Math.floor(Math.random() * 5)) + 3);
    shapeYSpeed = Math.floor(Math.random() * (Math.floor(Math.random() * 5)) + 2);
    createCharacter(300,400,400);
}

function draw()
{
    background(400,10,16);
    stroke(2);
    fill(0);
    
    createBorders(8.6);

    textSize(13);
    text("Escape", width-50,height-30)


    drawCharacter();
    characterMovement();


    fill(80,14,20);
    circle(shapeX, shapeY, 10,40);

     shapeXSpeed = Math.floor(Math.random() * (Math.floor(Math.random() * 5)) + 5);
     shapeYSpeed = Math.floor(Math.random() * (Math.floor(Math.random() * 5)) + 5);


    shapeX += shapeXSpeed;
    shapeY += shapeYSpeed;
    if(shapeX > width)
    {
        shapeX = 1;
    }
    if(shapeX < 1)
    {
        shapeX = width;
    }
    if(shapeY > height)
    {
        shapeY = 1;
    }
    if(shapeY < 1)
    {
        shapeY = height;
    }

    if(characterX > width && characterY > width-50)
    {
        fill(0);
        stroke(5);
        textSize(26);
        text("Victory", width/2-50, height/2-30);
    }
    fill(800,90,800);
    circle(mouseShapeX, mouseShapeY, 15);
}

function characterMovement()
{
    if(keyIsDown(UP_ARROW))
    {
        characterY -= 10;   
    }
    if(keyIsDown(DOWN_ARROW))
    {
        characterY += 10;   
    }
    if(keyIsDown(LEFT_ARROW))
    {
        characterX -= 10;   
        console.log("movement: " + characterX);
    }
    if(keyIsDown(RIGHT_ARROW))
    {
        characterX += 10;   
    }
}
function createCharacter(x,y)
{
    characterX = x;
    characterY = y;
    console.log(characterX);

}

function drawCharacter()
{
    fill(100,40,123);
    circle(characterX,characterY,25);
}
function createBorders(thickness)
{

    rect(0,0,width,thickness);

    rect(0,0,thickness,height);
    
    rect(0, height-thickness,width, thickness);
    
    rect(width-thickness,0,thickness,height-50);
}

function mouseClicked()
{
    mouseShapeX = mouseX;
    mouseShapeY = mouseY;
}
/*
function keyPressed() {
    if (keyCode === LEFT_ARROW) {
        characterX -= 10;
    } 
    else if (keyCode === RIGHT_ARROW) {
        characterX += 10;
    }
    else if (keyCode === UP_ARROW) {
        characterY -= 10;
    }
    else if (keyCode === DOWN_ARROW) {
        characterY += 10;
    }
  }
  */