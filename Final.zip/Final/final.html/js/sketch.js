var shapeX = 70;
var shapeY = 90;
var shapeXSpeed;
var shapeYSpeed;

var size = 22;
var count = 0;
var sizeDirection = 2;
function setup()
 {
     createCanvas(1000,600);
     shapeXSpeed = Math.floor(Math.random() * (Math.floor(Math.random() * 5)) + 9);
     shapeYSpeed = Math.floor(Math.random() * (Math.floor(Math.random() * 5)) + 9);
     
 }
 function draw()
 {
     background(100,96,60);
     textSize(30);
     textSize(size);
     size+= sizeDirection;
     count++;
     if(count > 5)
     {
         sizeDirection *=-1;
         count = 0;
     }

    fill(80,15,104);
    circle(shapeX, shapeY, 90);

     shapeXSpeed = Math.floor(Math.random() * (Math.floor(Math.random() * 5)) + 8);
     shapeYSpeed = Math.floor(Math.random() * (Math.floor(Math.random() * 5)) + 8);

    
    shapeX += shapeXSpeed;
    shapeY += shapeYSpeed;
    if(shapeX > width)
    {
        shapeX = 0;
    }
    if(shapeX < 0)
    {
        shapeX = width;
    }
    if(shapeY > height)
    {
        shapeY = 0;
    }
    if(shapeY < 0)
    {
        shapeY = height;
    }
     textSize(60);
fill(300,80,82);
    text('I Love Movies!', 300, 300);
    textSize(25);
text('My Favorite Movies:', 40, 480);
textSize(20);
text('The Incredibles, Pulp Fiction, Ghostbusters, Alien, The Thing, Back to the Future', 40, 510);

    fill(100,100,100);
circle(100,180,150);

fill(100,96,60);
circle(100,180,50);

fill(62,170,90);
rect(800,110,140,190);

textSize(28);
fill(3,3,3);
text('DVD Case', 800, 180);

    }