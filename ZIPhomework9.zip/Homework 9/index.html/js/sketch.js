function setup()
 {
     createCanvas(500,600);
 }
 function draw()
 {
     background(80,40,70);
     textSize(30);
    text('A Portrait of Chris', 2, 30);
    textSize(22);
    text('by: Chris Shields', 2, 50);
    ellipse(220,175,100,105);
    strokeWeight(8);
    point (197,168);
    point (245, 170)
    triangle(220, 175, 180, 185, 195, 200);
    rect(210,228,20,30);
    rect(170,250,100,200);
    line(170,300, 75, 205);
    circle(62,179,55);
    line(270,300,390,300);
    circle(390,300,55);
 }