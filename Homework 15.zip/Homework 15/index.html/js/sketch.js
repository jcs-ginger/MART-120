
var characterX = 80;
var characterY = 80;

var UP_ARROW = 80; 
var DOWN_ARROW = 80;
var LEFT_ARROW = 80;
var RIGHT_ARROW = 80;

var shapeX = 30;
var shapeY = 50;

var shapeXs = [];
var shapeYs = [];
var diameters = [];

var shapeXSpeeds = [];
var shapeYSpeeds = [];

var mouseShapeX;
var mouseShapeY;

function setup() {
    createCanvas(800, 400);

    
    for (var i = 0; i < 50; i++) {
    shapeXSpeeds[i] = Math.floor(Math.random() * (Math.floor(Math.random() * 5)) + 1);
    shapeYSpeeds[i] = Math.floor(Math.random() * (Math.floor(Math.random() * 5)) + 1);
    shapeXs[i] = getRandomNumber(500);
    shapeYs[i] = getRandomNumber(600);
    diameters[i] = getRandomNumber(30);
 }
    createCharacter(300,400);
}

function draw()
{
    background(400,10,16);
    stroke(2);
    fill(0);
    createBorders(8.6);

    textSize(13);
    text("Escape", width - 50,height - 50)

    drawCharacter();
    characterMovement();


    fill(80,14,20);
    for (var i = 0; i < shapeXs.length; i++) {
    circle(shapeXs[i], shapeYs[i], diameters[i]);
     shapeXSpeeds[i] = Math.floor(Math.random() * (Math.floor(Math.random() * 5)) + 1);
     shapeYSpeeds[i] = Math.floor(Math.random() * (Math.floor(Math.random() * 5)) + 1);


    shapeXs[i] += shapeXSpeeds[i];
    shapeYs[i] += shapeYSpeeds[i];

    if(shapeXs[i] > width) {
        shapeXs[i] = 0;
    }
    if(shapeXs[i] < 0)
    {
        shapeXs[i] = width;
    }
    if(shapeYs[i] > height)
    {
        shapeYs[i] = 0;
    }
    if(shapeYs[i] < 0)
    {
        shapeYs[i] = height;
    }

    if(characterX > width && characterY > width - 50) {
        fill(0);
        stroke(5);
        textSize(26);
        text("Victory", width / 2 - 50, height / 2 - 30);
    }
    fill(800,90,800);
    circle(mouseShapeX, mouseShapeY, 15);
}

function characterMovement() {
    if(keyIsDown(UP_ARROW))
    {
        characterY -= 10;   
    }
    if(keyIsDown(DOWN_ARROW))
    {
        characterY += 10;   
    }
    if(keyIsDown(LEFT_ARROW))
    {
        characterX -= 10;   
        console.log("movement: " + characterX);
    }
    if(keyIsDown(RIGHT_ARROW))
    {
        characterX += 10;   
    }
}
function createCharacter(x, y) {
    characterX = x;
    characterY = y;

}

function drawCharacter() {
    fill(100,40,123);
    circle(characterX,characterY,25);
}
function createBorders(thickness) {

    rect(0, 0, width, thickness);

    rect(0, 0, thickness, height);
    
    rect(0, height - thickness, width, thickness);
    
    rect(width - thickness, 0, thickness, height - 50);
}

function mouseClicked() {
    mouseShapeX = mouseX;
    mouseShapeY = mouseY;
}
function getRandomNumber(number) {
    return Math.floor(Math.random() * number) + 10;
}}