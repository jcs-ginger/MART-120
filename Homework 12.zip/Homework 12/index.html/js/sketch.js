// x and y for my character
var characterX = 80;
var characterY = 80;
// define the key codes for each letter
var UP_ARROW = 80; 
var DOWN_ARROW = 80;
var LEFT_ARROW = 80;
var RIGHT_ARROW = 80;

// x and y for a shape
var shapeX = 50;
var shapeY = 50;
var shapeXSpeed = 80;
var shapeYSpeed = 80;

// create a shape when the mouse is clicked
var mouseShapeX;
var mouseShapeY;
function setup()
{
    createCanvas(800, 400);
    // get a random speed when the it first starts
    shapeXSpeed = Math.floor(Math.random() * (Math.floor(Math.random() * 5)) + 3);
    shapeYSpeed = Math.floor(Math.random() * (Math.floor(Math.random() * 5)) + 2);
    createCharacter(300,400,400);
}

function draw()
{
    background(400,10,16);
    stroke(2);
    fill(0);
    
    // call createBorders function
    createBorders(8.6);

    // exit message
    textSize(13);
    text("Escape", width-50,height-30)

    //createCharacter(480,200);
    drawCharacter();
    characterMovement();


    // potential enemy
    fill(80,14,20);
    // draw the shape
    circle(shapeX, shapeY, 10,40);

     // get a random speed when the it first starts
     shapeXSpeed = Math.floor(Math.random() * (Math.floor(Math.random() * 5)) + 5);
     shapeYSpeed = Math.floor(Math.random() * (Math.floor(Math.random() * 5)) + 5);

    // move the shape
    shapeX += shapeXSpeed;
    shapeY += shapeYSpeed;
    // check to see if the shape has gone out of bounds
    if(shapeX > width)
    {
        shapeX = 1;
    }
    if(shapeX < 1)
    {
        shapeX = width;
    }
    if(shapeY > height)
    {
        shapeY = 1;
    }
    if(shapeY < 1)
    {
        shapeY = height;
    }

    // check to see if the character has left the exit
    if(characterX > width && characterY > width-50)
    {
        fill(0);
        stroke(5);
        textSize(26);
        text("Victory", width/2-70, height/2-70);
    }

    // create the shape based on the mouse click
    fill(800,90,800);
    circle(mouseShapeX, mouseShapeY, 15);
}

function characterMovement()
{
    // handle the keys
    if(keyIsDown(UP_ARROW))
    {
        characterY -= 10;   
    }
    if(keyIsDown(DOWN_ARROW))
    {
        characterY += 10;   
    }
    if(keyIsDown(LEFT_ARROW))
    {
        characterX -= 10;   
        console.log("movement: " + characterX);
    }
    if(keyIsDown(RIGHT_ARROW))
    {
        characterX += 10;   
    }
}
function createCharacter(x,y)
{
    characterX = x;
    characterY = y;
    console.log(characterX);
    //character
    
   // circle(characterX,characterY,25);
}

function drawCharacter()
{
    fill(100,40,123);
    circle(characterX,characterY,25);
}
function createBorders(thickness)
{
    // top border
    rect(0,0,width,thickness);
    // left border
    rect(0,0,thickness,height);
    // bottom border
    rect(0, height-thickness,width, thickness);
    // right upper border
    rect(width-thickness,0,thickness,height-50);
}

function mouseClicked()
{
    mouseShapeX = mouseX;
    mouseShapeY = mouseY;
}
/*
function keyPressed() {
    if (keyCode === LEFT_ARROW) {
        characterX -= 10;
    } 
    else if (keyCode === RIGHT_ARROW) {
        characterX += 10;
    }
    else if (keyCode === UP_ARROW) {
        characterY -= 10;
    }
    else if (keyCode === DOWN_ARROW) {
        characterY += 10;
    }
  }
  */